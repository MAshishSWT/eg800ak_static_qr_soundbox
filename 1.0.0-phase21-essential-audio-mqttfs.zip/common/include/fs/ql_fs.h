/*================================================================
  Copyright (c) 2021, Quectel Wireless Solutions Co., Ltd. All rights reserved.
  Quectel Wireless Solutions Proprietary and Confidential.
=================================================================*/

#ifndef _QL_FS_H
#define _QL_FS_H

#include "ql_type.h"
#include "lfs.h"

#define QFS_ID_MAX     3
#define NAND_FILE_NAME_SIZE 128

typedef unsigned int FILE_ID;

typedef struct
{
	int fs_id;
	lfs_file_t file;
} QFILE;

typedef struct
{
	int fs_id;
	lfs_dir_t dir;
} QDIR;

struct ql_yaffs_dev
{
    const char *name;
    u32 start_block;    
    u32 end_block;
};

typedef struct 
{   
    // Type of the file, either TYPE_REG:0 or TYPE_DIR:1
    UINT8 type;

    // Size of the file, only valid for REG files
    unsigned int size;

    // Name of the file stored as a null-terminated string
    char name[NAND_FILE_NAME_SIZE];
}NandFs_info;

#define U_DISK_SYM	'U'
#define B_DISK_SYM	'B'

#define PATH_MAX				260

typedef struct QL_TAG_TIME_INFO_STRUCT
{
        unsigned int    m_nMilliSec             : 10;   //Million second, 0-999
        unsigned int    m_nYear                 : 12;   //Year, 0-4095
        unsigned int    m_nReserved1    		  : 10;   //Reserved, Zero always
        unsigned int    m_nMonth                : 4;    //Month, 1-12
        unsigned int    m_nDate                 : 5;    //Day, 1-31
        unsigned int    m_nHour                 : 5;    //Hour, 0-23
        unsigned int    m_nMinute               : 6;    //Minute, 0-59
        unsigned int    m_nSecond               : 6;    //Second, 0-59
        unsigned int    m_nDayOfWeek    		  : 3;    //Day of week, 1-7
        unsigned int    m_nReserved2         	  : 3;    //Reserved, Zero always
}QL_TIMEINFO_T, *QL_LPTIMEINFO_T;

//	File Info defination
typedef	struct	QL_TAG_FS_FILE_INFO_STRUCT
{
	unsigned int		m_nSize;			//The size of the struct
	unsigned int		m_nMask;			//The op mask
	QL_TIMEINFO_T	m_tCreate;			//The create datetime
	QL_TIMEINFO_T	m_tModify;			//The modify datetime
	QL_TIMEINFO_T	m_tAccess;			//The access datetime
	unsigned int		m_nFileSize;		//The file size
	unsigned int		m_nAttr;			//The attribute
	unsigned short  	m_lpszFullName[PATH_MAX + 4];	//The full path
}QL_FSFILEINFO_T, *QL_LPFSFILEINFO_T;


typedef	struct	QL_TAG_FAT32FILEINFO_STRUCT
{
    QL_FSFILEINFO_T info;
    char name[100];
}QL_FAT32FILEINFO_T, *QL_LPFAT32FILEINFO_T;

typedef struct QL_FS_INFO_STRUCT
{
    long long iToTalSize;
	long long iUsedSize;
}QL_FS_INFO_T;

/*-----------------------------------------------------------------------------------------
 * Function: Format file system according to disk character
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fs_format(char disk_sym);

/*-----------------------------------------------------------------------------------------
 * Function: Mount file system according to disk character
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fs_mount(char disk_sym);

/*-----------------------------------------------------------------------------------------
 * Function: Unmount file system according to disk character
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fs_unmount(char disk_sym);

/*-----------------------------------------------------------------------------------------
 * Function: Get file system size according to disk character
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fs_size(char disk_sym);

/*-----------------------------------------------------------------------------------------
 * Function: Get file system used size according to disk character
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fs_used_size(char disk_sym);

/*-----------------------------------------------------------------------------------------
 * Function: Get file system free size according to disk character
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fs_free_size(char disk_sym);

/*-----------------------------------------------------------------------------------------
 * Function: Open file in the file system
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *    <mode>: 	[IN] Open mode .
 *		
 * Return:
 *    File stream.
-----------------------------------------------------------------------------------------*/
QFILE * ql_fopen(const char *fname, const char *mode);

/*-----------------------------------------------------------------------------------------
 * Function: Open file in the file system
 *
 * Parameter:
 *    <fp>: 	[IN] File stream.
 *		
 * Return:
 *   LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fclose(QFILE * fp);

/*-----------------------------------------------------------------------------------------
 * Function: Synchronization File in the file system
 *
 * Parameter:
 *    <fp>: 	[IN] File stream.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fsync(QFILE * fp);

/*-----------------------------------------------------------------------------------------
 * Function: Read file
 *
 * Parameter:
 *    <buffer>: [OUT] File read buff.
 *    <size>: 	[IN] File read size.
 *    <num>:	[IN] File read format size.
 *    <fp>: 	[IN] File stream.
 *		
 * Return:
 *    Real read size.
-----------------------------------------------------------------------------------------*/
int ql_fread(void * buffer, size_t size, size_t num, QFILE * fp);

/*-----------------------------------------------------------------------------------------
 * Function: Write file
 *
 * Parameter:
 *    <buffer>: [IN] File write buff.
 *    <size>: 	[IN] File write size.
 *    <num>:	[IN] File write format size.
 *    <fp>: 	[IN] File stream.
 *		
 * Return:
 *    Real write size.
-----------------------------------------------------------------------------------------*/
int ql_fwrite(void * buffer, size_t size, size_t num, QFILE * fp);

/*-----------------------------------------------------------------------------------------
 * Function: Write one character into file
 *
 * Parameter:
 *    <chr>: [IN] File write character.
 *    <fp>:  [IN] File stream.
 *		
 * Return:
 *    Real write size.
-----------------------------------------------------------------------------------------*/
int ql_fputc(int chr, QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Write string into file
 *
 * Parameter:
 *    <chr>: [IN] File write string.
 *    <fp>:  [IN] File stream.
 *		
 * Return:
 *    Real write size.
-----------------------------------------------------------------------------------------*/
int ql_fputs(const char *str, QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Format write string into file
 *
 * Parameter:
 *    <fp>:     [IN] File stream.
 *    <format>: [IN] File format.
 *		
 * Return:
 *    Real write size.
-----------------------------------------------------------------------------------------*/
int ql_fprintf(QFILE *fp, const char *format, ...);

/*-----------------------------------------------------------------------------------------
 * Function: Read one character from file
 *
 * Parameter:
 *    <fp>:  [IN] File stream.
 *		
 * Return:
 *    Read character.
-----------------------------------------------------------------------------------------*/
int ql_fgetc(QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Read string from file
 *
 * Parameter:
 *    <fpstr>:  [OUT] Read buff.
 *    <n>:      [IN] Read lengths.
 *    <fp>:     [IN] File stream.
 *		
 * Return:
 *    Read string.
-----------------------------------------------------------------------------------------*/
char *ql_fgets(char *str, int n, QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Format read string from file
 *
 * Parameter:
 *    <fp>:     [IN] File stream.
 *    <format>: [IN] File format.
 *		
 * Return:
 *    Real read size.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fscanf(QFILE *fp, const char *format, ...);


/*-----------------------------------------------------------------------------------------
 * Function: Relocate file pointer
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *    <offset>: 	[IN] off set.
 *    <origin>:     [IN] Starting position.
 *		
 * Return:
 *     LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_fseek(QFILE *fp, long offset, int origin);

/*-----------------------------------------------------------------------------------------
 * Function: File truncate
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *    <length>:    [IN] truncate size.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_ftruncate(QFILE *fp, u32 length);

/*-----------------------------------------------------------------------------------------
 * Function: Get the current location of the file pointer
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *		
 * Return:
 *    Current location of the file pointer.
-----------------------------------------------------------------------------------------*/
long ql_ftell(QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Set file location to given stream
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *		
 * Return:
 *    
-----------------------------------------------------------------------------------------*/
int ql_frewind(QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Get file size
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *		
 * Return:
 *    File size.
-----------------------------------------------------------------------------------------*/
int ql_fsize(QFILE *fp);

/*-----------------------------------------------------------------------------------------
 * Function: Create directory
 *
 * Parameter:
 *    <path>: 	[IN] Directory path.
 *    <mode>: 	[IN] create mode.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_mkdir(const char *path, u32 mode);

/*-----------------------------------------------------------------------------------------
 * Function: Open directory
 *
 * Parameter:
 *    <path>: 	[IN] Directory path.
 *    <mode>: 	[IN] create mode.
 *		
 * Return:
 *    Directory stream.
-----------------------------------------------------------------------------------------*/
QDIR * ql_opendir(const char *path);

/*-----------------------------------------------------------------------------------------
 * Function: Open directory
 *
 * Parameter:
 *    <dp>: 	[IN] Directory stream.
 *		
 * Return:
 *    Directory stream.
-----------------------------------------------------------------------------------------*/
int ql_closedir(QDIR *dp);

/*-----------------------------------------------------------------------------------------
 * Function: Read directory
 *
 * Parameter:
 *    <dp>: 	[IN] Directory stream.
 *    <info>: 	[IN] File info structure ..
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_readdir(QDIR *dp, struct lfs_info *info);

/*-----------------------------------------------------------------------------------------
 * Function: Relocate directory pointer
 *
 * Parameter:
 *    <dp>: 	[IN] Directory stream.
 *    <loc>: 	[IN] Relocate position.
 *		
 * Return:
 *    
-----------------------------------------------------------------------------------------*/
int ql_seekdir(QDIR *dp, long int loc);

/*-----------------------------------------------------------------------------------------
 * Function: Get the current location of the directory pointer
 *
 * Parameter:
 *    <dp>: 	[IN] Directory stream.
 *		
 * Return:
 *    Current location of the directory pointer.
-----------------------------------------------------------------------------------------*/
long ql_telldir(QDIR *dp);

/*-----------------------------------------------------------------------------------------
 * Function: Set directory location to given stream
 *
 * Parameter:
 *    <dp>: 	[IN] Directory stream.
 *		
 * Return:
 *    
-----------------------------------------------------------------------------------------*/
int ql_rewinddir(QDIR *dp);

/*-----------------------------------------------------------------------------------------
 * Function: Remove files in the file system
 *
 * Parameter:
 *    <fname>: 	[IN] File name.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_remove(const char *fname);

/*-----------------------------------------------------------------------------------------
 * Function: Rename files 
 *
 * Parameter:
 *    <oldpath>: 	[IN] File oldpath.
 *    <newpath>: 	[IN] File newpath.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_rename(const char *oldpath, const char *newpath);

/*-----------------------------------------------------------------------------------------
 * Function: Copy files 
 *
 * Parameter:
 *    <oldpath>: 	[IN] File old path.
 *    <newpath>: 	[IN] File new path.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_copy(const char *oldpath, const char *newpath);

/*-----------------------------------------------------------------------------------------
 * Function: Judge whether the file exists
 *
 * Parameter:
 *    <path>: 	[IN] File path.
 *    <mode>: 	[IN] File mode.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_access(const char *path, u32 mode);

/*-----------------------------------------------------------------------------------------
 * Function: Find info about a directory
 *
 * Parameter:
 *    <path>: 	[IN] File path.
 *    <info>: 	[IN] File info structure.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_stat(const char *path, struct lfs_info *info);
/***********************************************************************
 *
 * Name:		ql_FDI_fopen
 *
 * Description: used in an implementation-specified matter to open or create a file and
*    associate it with a stream.
 *
 * Parameters:
 *  char                 *filename_ptr      [IN]    const character string for file name specifier.
*  char			*mode                [IN] 	const character string for type specification;
 *
 * Returns:
 *	the stream index used for the opened file.
 *    If an error is detected, FDI_fopen returns 0.
 *
 * Notes:
 *
 ***********************************************************************/
FILE_ID ql_FDI_fopen(const char *filename_ptr, const char *mode);
/***********************************************************************
 *
 * Name:		ql_FDI_fclose
 *
 * Description: used to close a file stream.
 *
 * Parameters:
 *  FILE_ID                 stream      [IN]    stream index for the file to be closed.
 *
 * Returns:
 *		0:   pass
 * 	 	EOF: fail
 * Notes:
 *
 ***********************************************************************/
int ql_FDI_fclose(FILE_ID stream);
/***********************************************************************
 *
 * Name:		ql_FDI_fread
 *
 * Description: read file.
 *
 * Parameters:
 *	 void		*buffer_ptr   	[OUT]	pointer to buffer to place data read
 *	size_t		element_size 	[IN] 		size of element referenced by buffer pointer
 *	size_t		count    		[IN]		number of elements to be read
 *	FILE_ID 		stream		[IN]		stream index for the file to be closed.
 *
 * Returns:
 *		number of elements succesfully read
 * Notes:
 *
 ***********************************************************************/
size_t ql_FDI_fread(void *buffer_ptr, size_t element_size, size_t count, FILE_ID stream);
/***********************************************************************
 *
 * Name:		ql_FDI_fwrite
 *
 * Description: write file.
 *
 * Parameters:
 *	 void		*buffer_ptr   	[IN]		pointer to buffer to be written
 *	size_t		element_size 	[IN] 		size of element referenced by buffer pointer
 *	size_t		count    		[IN]		number of elements to be read
 *	FILE_ID 		stream		[IN]		stream index for the file to be closed.
 *
 * Returns:
 *		number of elements succesfully write
 * Notes:
 *
 ***********************************************************************/
size_t ql_FDI_fwrite(const void *buffer_ptr,size_t element_size,size_t count,FILE_ID stream);
/***********************************************************************
 *
 * Name:		ql_FDI_fseek
 *
 * Description: sets the file position indicator of the file specified  by stream.
 *				The new position, measured in bytes from the beginning of the file
 *				is obtained by adding offset to the position specified by wherefrom.
 *
 * Parameters:
 *    FILE_ID                 stream      [IN]    stream index for the file
 *	long				offset 	[IN] 		the offset to obtain to the position indicator (in bytes)
 *	int				wherefrom    		[IN]		the position to add offset(SEEK_SET, SEEK_CUR, SEEK_END)

 *
 * Returns:
  *		0:  pass
 * 	 	EOF: fail
 * Notes:
 *
 ***********************************************************************/

int ql_FDI_fseek(FILE_ID stream, long offset, int wherefrom);

/***********************************************************************
 *
 * Name:		ql_FDI_GetFileSize
 *
 * Description:  get file size
 *
 * Parameters:
 *  int                 fd      [IN]    file handler
 *
 * Returns:
 * 	 	file length
 * Notes:
 *
 ***********************************************************************/
unsigned int ql_FDI_GetFileSize(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: Open file in the nand flash
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *    <mode>: 	[IN] Open mode .
 *		
 * Return:
 *    File stream.
-----------------------------------------------------------------------------------------*/
FILE_ID ql_nand_fopen(const char *filename_ptr, const char *mode);

/*-----------------------------------------------------------------------------------------
 * Function: Open file in the nand flash
 *
 * Parameter:
 *    <fp>: 	[IN] File stream.
 *		
 * Return:
 *   LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_fclose(FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Read file in the nand flash
 *
 * Parameter:
 *    <buff>: [OUT] File read buff.
 *    <size>: 	[IN] File read size.
 *    <count>:	[IN] File read format size.
 *    <stream>: 	[IN] File stream.
 *		
 * Return:
 *    Real read size.
-----------------------------------------------------------------------------------------*/
int ql_nand_fread(void *buff, size_t element_size, size_t count, FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Write file in the nand flash
 *
 * Parameter:
 *    <buff>: [IN] File write buff.
 *    <size>: 	[IN] File write size.
 *    <count>:	[IN] File write format size.
 *    <stream>: 	[IN] File stream.
 *		
 * Return:
 *    Real write size.
-----------------------------------------------------------------------------------------*/
int ql_nand_fwrite(const void *buff, size_t element_size, size_t count, FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Relocate file pointer in the nand flash
 *
 * Parameter:
 *    <stream>:         [IN] File stream.
 *    <offset>: 	[IN] off set.
 *    <wherefrom>:     [IN] Starting position.
 *		
 * Return:
 *     LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_fseek(FILE_ID stream, long offset, int wherefrom);

/*-----------------------------------------------------------------------------------------
 * Function: Remove files in the nand flash
 *
 * Parameter:
 *    <filename_ptr>: 	[IN] File name.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_fremove(const char *filename_ptr);

//20201013 august end


//20201221 august add to SPI nand flash
/*-----------------------------------------------------------------------------------------
 * Function: Rename the nand file
 *
 * Parameter:
 *    <oldpath>: 	[IN] File oldpath.
 *    <newpath>: 	[IN] File newpath.
 *		
 * Return:
 *    0: no error.
 *   -1:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_frename(char *name, char *new_name);

/*-----------------------------------------------------------------------------------------
  * Function: Get nand file size
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *		
 * Return:
 *    File size.
-----------------------------------------------------------------------------------------*/
int ql_nand_fsize(char *file_name);

/*-----------------------------------------------------------------------------------------
 * Function: Create directory
 *
 * Parameter:
 *    <path>: 	[IN] Directory path.
 *		
 * Return:
 *    0: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int	ql_nand_mkdir(char *dir_name);

/*-----------------------------------------------------------------------------------------
 * Function: Judge whether the file exists
 *
 * Parameter:
 *    <path>: 	[IN] File name.
 *		
 * Return:
 *    1: exists.
 *    0: no exists
-----------------------------------------------------------------------------------------*/
int ql_nand_access(char *file_name);
//20201221 august end

/*-----------------------------------------------------------------------------------------
 * Function: Get the remaining space of the file system
 *
 * Parameter:
 *		
 * Return:
 *   	Free space size(For reference only)
-----------------------------------------------------------------------------------------*/
int ql_nand_get_free_size(void);

/*-----------------------------------------------------------------------------------------
 * Function: Format the file system
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
void ql_nand_format(void);

/*-----------------------------------------------------------------------------------------
 * Function: qfs_init �����ļ�ϵͳ��ָ������
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int qfs_init(char disk_sym, char *patition_name, unsigned char is_format);
/*-----------------------------------------------------------------------------------------
 * @brief   �˺������ڽ�ĳ����������������fs����������/��ʽ��Ϊ�ļ�ϵͳ�������̷�
 * @param[in] disk_sym  		�������1������
 * @param[in] patition_name  	��Ҫ��ʽ��/���صķ���
 * @param[in] is_format 		�Ƿ��ʽ��
 * @param[in] spi_port 			spi�˿�
 * @param[in] startaddr 		�����������ʼ��ַ
 * @param[in] size 				��Ҫ��ʽ���Ĵ�С����СӦΪ0X8000��32K��
 * @return     	���سɹ�/ʧ�� = 0/1 
 * 				���ĳ�������ѱ���ʼ�����򷵻�ʧ��
 * 				���ĳ���̷��ѱ�ʹ�ã��򷵻�ʧ��
 * @warning		��������Ӧ���ڣ���ʼ��ַ����СӦ���������ļ����õķ�������(����aboot�鿴)
-----------------------------------------------------------------------------------------*/
int qextfs_init(char disk_sym, char *patition_name, unsigned char is_format, unsigned char spi_port, unsigned int startaddr, unsigned int size);

/*-----------------------------------------------------------------------------------------
 * Function: ql_load_per_size_set  ����lfs ���ζ�д���ݵ�size������С���ݶ�дʱ������Ķ�д���
 *
 * Parameter: read_size : ��lfs���ݣ����ζ�ȡ���ֽ��� ������4�ֽڶ���
 *            prog_size : дlfs���ݣ�����д����ֽ��� ������4�ֽڶ���
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int ql_set_flash_atomic_size(unsigned int read_size,unsigned int prog_size);
/*-----------------------------------------------------------------------------------------
 * Function: Open file in the nand flash
 *
 * Parameter:
 *    <fs_id>: 	[IN] Disk character.
 *    <mode>: 	[IN] Open mode .
 *		
 * Return:
 *    File stream.
-----------------------------------------------------------------------------------------*/
FILE_ID ql_nand_fopen(const char *filename_ptr, const char *mode);

/*-----------------------------------------------------------------------------------------
 * Function: Open file in the nand flash
 *
 * Parameter:
 *    <fp>: 	[IN] File stream.
 *		
 * Return:
 *   LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_fclose(FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Read file in the nand flash
 *
 * Parameter:
 *    <buff>: [OUT] File read buff.
 *    <size>: 	[IN] File read size.
 *    <count>:	[IN] File read format size.
 *    <stream>: 	[IN] File stream.
 *		
 * Return:
 *    Real read size.
-----------------------------------------------------------------------------------------*/
int ql_nand_fread(void *buff, size_t element_size, size_t count, FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Write file in the nand flash
 *
 * Parameter:
 *    <buff>: [IN] File write buff.
 *    <size>: 	[IN] File write size.
 *    <count>:	[IN] File write format size.
 *    <stream>: 	[IN] File stream.
 *		
 * Return:
 *    Real write size.
-----------------------------------------------------------------------------------------*/
int ql_nand_fwrite(const void *buff, size_t element_size, size_t count, FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Relocate file pointer in the nand flash
 *
 * Parameter:
 *    <stream>:         [IN] File stream.
 *    <offset>: 	[IN] off set.
 *    <wherefrom>:     [IN] Starting position.
 *		
 * Return:
 *     LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_fseek(FILE_ID stream, long offset, int wherefrom);

/*-----------------------------------------------------------------------------------------
 * Function: Relocate file pointer in the nand flash
 *
 * Parameter:
 *    <stream>:         [IN] File stream.
 *    <offset>: 	[IN] off set.
 *    <wherefrom>:     [IN] Starting position.
 *		
 * Return:
 *    the current location of the file pointer,
 *	  which returns -1 on an error call 
 *   
-----------------------------------------------------------------------------------------*/

int ql_nand_lseek(FILE_ID stream, long offset, int wherefrom);

/*-----------------------------------------------------------------------------------------
 * Function: Gets the number of bytes offset from the current position of
 * the file pointer to the beginning of the file
 * Parameter:
 *    <stream>:         [IN] File stream.
 *		
 * Return:
 *     offset bytes, which returns -1 on an error call
 *    
-----------------------------------------------------------------------------------------*/

int ql_nand_ftell(FILE_ID stream);

/*-----------------------------------------------------------------------------------------
 * Function: Remove files in the nand flash
 *
 * Parameter:
 *    <filename_ptr>: 	[IN] File name.
 *		
 * Return:
 *    LFS_ERR_OK: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_fremove(const char *filename_ptr);

//20201013 august end


//20201221 august add to SPI nand flash
/*-----------------------------------------------------------------------------------------
 * Function: Rename the nand file
 *
 * Parameter:
 *    <oldpath>: 	[IN] File oldpath.
 *    <newpath>: 	[IN] File newpath.
 *		
 * Return:
 *    0: no error.
 *   -1:  error
-----------------------------------------------------------------------------------------*/
int ql_nand_frename(char *name, char *new_name);

/*-----------------------------------------------------------------------------------------
  * Function: Get nand file size
 *
 * Parameter:
 *    <fp>:         [IN] File stream.
 *		
 * Return:
 *    File size.
-----------------------------------------------------------------------------------------*/
int ql_nand_fsize(char *file_name);

/*-----------------------------------------------------------------------------------------
 * Function: Create directory
 *
 * Parameter:
 *    <path>: 	[IN] Directory path.
 *		
 * Return:
 *    0: no error.
 *    other:  error
-----------------------------------------------------------------------------------------*/
int	ql_nand_mkdir(char *dir_name);

/*-----------------------------------------------------------------------------------------
 * Function: Judge whether the file exists
 *
 * Parameter:
 *    <path>: 	[IN] File name.
 *		
 * Return:
 *    1: exists.
 *    0: no exists
-----------------------------------------------------------------------------------------*/
int ql_nand_access(char *file_name);
//20201221 august end

/*-----------------------------------------------------------------------------------------
 * Function: Get the remaining space of the file system
 *
 * Parameter:
 *		
 * Return:
 *   	Free space size(For reference only)
-----------------------------------------------------------------------------------------*/
int ql_nand_get_free_size(void);

/*-----------------------------------------------------------------------------------------
 * Function: Format the file system
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
void ql_nand_format(void);
/*-----------------------------------------------------------------------------------------
 * Function: Format the file system ��ʼ��nand spi
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int ql_spi_nand_init(int spi_port, int spi_pin,int spi_clk);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_removedir ��ʼ��nand spi
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int	ql_nand_removedir(char *dir_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_closedir ��ʼ��nand spi
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int	ql_nand_closedir(FILE_ID hDirID);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_readddir ��ʼ��nand spi
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int	ql_nand_readddir(FILE_ID hDirID, NandFs_info *fileinfo_ptr);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_opendir ��ʼ��nand spi
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
FILE_ID	ql_nand_opendir(char *dir_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_lstat ��ȡ·�����ļ������ļ���
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int ql_nand_lstat(char *path,NandFs_info *fileinfo_ptr);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_fgets ��ȡ�ļ�һ���ַ�
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
char *ql_nand_fgets(char *str, int n, FILE_ID stream);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_fsync �޸Ķ���д�뵽���ô洢�豸
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int ql_nand_fsync(FILE_ID stream);
 /*-----------------------------------------------------------------------------------------
 * Function: ql_nand_yaffs_sync ����yaffs checkpoint�ӿ�
 *
 * Parameter:
 *		
 * Return:
 *   	 
  -----------------------------------------------------------------------------------------*/
int ql_nand_yaffs_sync(void);
 /*-----------------------------------------------------------------------------------------
  * Function: ql_nand_fgetc ��ȡһ���ַ�
  *
  * Parameter:
  * 	 
  * Return:
  * 	 
 -----------------------------------------------------------------------------------------*/
int ql_nand_fgetc(FILE_ID stream);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_feof �ļ��Ƿ��Ѿ��������ļ�����
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int ql_nand_feof(FILE_ID stream,char *file_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_nand_frewind �����õ��ļ�����ʼλ��
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int ql_nand_frewind(FILE_ID stream);
/*-----------------------------------------------------------------------------------------
 * Function: qfs_init �����ļ�ϵͳ��ָ������
 *
 * Parameter:
 * 	 
 * Return:
 * 	 
-----------------------------------------------------------------------------------------*/

int qfs_init(char disk_sym, char *patition_name, unsigned char is_format);
/*-----------------------------------------------------------------------------------------
 * Function: qextfs_init �����ļ�ϵͳ���ⲿflash
 *
 * Parameter:
 *		
 * Return:
 *   	
-----------------------------------------------------------------------------------------*/
int qextfs_init(char disk_sym, char *patition_name, unsigned char is_format, unsigned char spi_port, unsigned int startaddr, unsigned int size);

/*-----------------------------------------------------------------------------------------
 * Function: ql_fs_get_bk_erase_count ��ȡ�ļ�ϵͳÿ��block�Ĳ�д����,
 *			 ����AT+QERASECOUNT = 1�������󣬿�ʹ�ø�api��ѯblock��д����
 * Parameter:
 *      flash_addr[in]: ��0x80000000 ��ʼ���ļ�ϵͳflash��ַ�����磺0x00654000
 *		
 * Return:
 *   	flash_addr����block�Ĳ�д����
 *      -1:����ʧ�ܣ����flash_addr�Ƿ���customer_fs��Χ��
-----------------------------------------------------------------------------------------*/
int ql_fs_get_bk_erase_count(int flash_addr);



/****************************************yaffsԭ���ӿ�,֧�ַ���************************************************/
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_start_up YAFFS�ļ�ϵͳ�ĳ�ʼ��
 *
 * Parameter:
 *		
 * Return:
 *      ���ظ���:��ʾ��ʼ��ʧ��
 *   	
-----------------------------------------------------------------------------------------*/
int ql_yaffs_start_up(void);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_create_dev YAFFS�ļ�ϵͳ��ͬ�����Ĵ���
 *
 * Parameter:
 *		dev_config:�������ò���
 *                 
 * Return:
 *      ���ظ���:��ʾ����ʧ��
 *   	
-----------------------------------------------------------------------------------------*/
int ql_yaffs_create_dev(struct ql_yaffs_dev *dev_config);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_mount YAFFS�ļ�ϵͳ���أ�֧�ֲ�ͬ����
 *
 * Parameter:
 *		path:����·��
 *                 
 * Return:
 *      0:��ʾ���سɹ�
 *      ���ظ���:��ʾ����ʧ��
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_mount(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_unmount YAFFS�ļ�ϵͳ��ж�أ�֧�ֲ�ͬ����
 *
 * Parameter:
 *		path:����·��
 *                 
 * Return:
 *      0:��ʾж�سɹ�
 *      ���ظ���:��ʾж��ʧ��
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_unmount(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_open �ļ��Ĵ򿪻��ߴ���
 *
 * Parameter:
 *		path:�ļ�·��
 *		                
 * Return:
 *      ����ɹ�������һ���Ǹ����ļ�������
 *      ���ʧ�ܣ�����һ������
 *     
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_open(const char *filename, const char *mode);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_close �Ѵ��ļ��Ĺر�
 *
 * Parameter:
 *		fd:�ļ�������    
 *      
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_close(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_read �Ѵ��ļ��Ķ�ȡ
 *
 * Parameter:
 *      buff:ָ�����ڴ洢��ȡ���ݵĻ�������ָ��
 *		element_size:ÿ��Ԫ�صĴ�С�����ֽ�Ϊ��λ
 *      count:Ҫ��ȡ��Ԫ�ظ���
 *      fd:�ļ���������ָʾҪ���ж�ȡ���ݵ��ļ�
 *      
 * Return:
 *     ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_read(void *buff, size_t element_size, size_t count, int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_write �Ѵ��ļ���д��
 *
 * Parameter:
 *      buff:ָ�����ڴ洢д�����ݵĻ�������ָ��
 *		element_size:ÿ��Ԫ�صĴ�С�����ֽ�Ϊ��λ
 *      count:Ҫд���Ԫ�ظ���
 *      fd:�ļ���������ָʾҪд�����ݵ��ļ�
 *		                
 * Return:
 *     ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_write(const void *buff, size_t element_size, size_t count, int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_lseek �ı��ļ��ĵ�ǰ��/дλ�ã�ƫ������
 *
 * Parameter:
 *      fd:�ļ���������ָʾҪ�������ļ�
 *      offset:ƫ������ָ������� whence ������ƫ����
 *      whence:ָ��ƫ��������ʼλ��
 *		                
 * Return:
 *     ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_lseek(int fd, long offset, int whence);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_unlink �ļ���Ŀ¼��ɾ��
 *
 * Parameter:
 *	    path:ɾ���ļ���·��	 
 *  
 * Return:
 *     ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_unlink(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_fsize �ļ���С�Ļ�ȡ
 *
 * Parameter:
 *	    path:Ҫ��ȡ��С���ļ�·��	 
 *  
 * Return:
 *     ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_fsize(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_rename �ļ���������
 *
 * Parameter:
 *	    name:�ɵ��ļ�·����Ŀ¼·��
 *      new_name:�µ��ļ�·����Ŀ¼·��
 *
 * Return:
 *      ���ظ���:��ʾ���� 
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_rename(const char *name, const char *new_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_mkdir Ŀ¼�Ĵ���
 *
 * Parameter:
 *      dir_name:Ҫ������Ŀ¼��·��
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_mkdir(const char *dir_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_opendir Ŀ¼�Ĵ�
 *
 * Parameter:
 *      dir_name:Ҫ��Ŀ¼��·��     
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_opendir(const char *dir_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_closedir Ŀ¼�Ĺر�
 *
 * Parameter:
 *      dir_name:Ҫ�ر�Ŀ¼��·�� 
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int	ql_yaffs_closedir(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_rmdir Ŀ¼��ɾ��
 *
 * Parameter:
 *      dir_name:Ҫɾ��Ŀ¼��·�� 
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_rmdir(const char *dir_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_access ���ָ��·���ϵ��ļ���Ŀ¼�Ƿ���Է���
 *
 * Parameter:
 *      path:Ҫ�����ļ���Ŀ¼��·����
 *		                
 * Return:
 *      ���ظ���:��ʾ���� 
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_access(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_freespace YAFFS�ļ�ϵͳʣ��ռ�Ĳ�ѯ
 *
 * Parameter:
 *		path:ָ��Ҫ��ѯ���пռ���ļ�ϵͳ·����ͨ�����ļ�ϵͳ�Ĺ��ص���Ŀ¼��֧�ֲ�ͬ����
 *
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_freespace(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_fsync ��YAFFS�ļ�ϵͳ������������д��NANDFlash
 *
 * Parameter:
 *      fb:�ļ�������
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_fsync(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_sync YAFFS�ļ�ϵͳcheckpoint�ı���
 *
 * Parameter:
 *      path:�ļ�ϵͳ·����֧�ֲ�ͬ����
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_sync(const char *path);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_format YAFFS�ļ�ϵͳ�ĸ�ʽ����֧�ֲ�ͬ����
 *
 * Parameter:
 *      path:Ҫ��ʽ����YAFFS �ļ�ϵͳ
 *		unmount_flag:ж�ر�־ 0����ж�أ�1������ж��
 *      force_unmount_flag:ǿ��ж�ر�־ 0����ǿ��ж�أ�1��ǿ��ж��
 *      remount_flag:���¹��ر�־ 0�������¹��أ�1�����¹���
 *
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_format(const char *path, int unmount_flag, int force_unmount_flag, int remount_flag);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_ftell �ļ���ǰƫ��λ�õĻ�ȡ
 *
 * Parameter:
 *		fd:�ļ�������
 *
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_ftell(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_fgetc �Ӵ򿪵��ļ��л�ȡһ���ַ�
 *
 * Parameter:
 *      fd:�ļ�������       
 *
 * Return:
 *      ��ȡ���ַ�
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_fgetc(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_fgets �Ӵ򿪵��ļ��л�ȡһ���ַ���
 *
 * Parameter:
 *      str:ָ���ȡ���ݻ���bufָ��
 *      n:��ȡ���ݵĸ���
 *      fd:�ļ�������
 *		                
 * Return:
 *      ����NULL����ʾ��ȡ�ַ���ʧ��
 *
-----------------------------------------------------------------------------------------*/
char *ql_yaffs_fgets(char *str, int n, int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_feof ����Ƿ���ƫ�Ƶ��ļ�ĩβ
 *
 * Parameter:
 *      fd:�ļ�������
 *      file_name:�ļ�·��
 *		                
 * Return:
 *      1:��ʾ��ƫ�Ƶ��ļ�ĩβ
 *      0:��ʾδƫ�Ƶ��ļ�ĩβ
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_feof(int fd, const char *file_name);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_frewind �����ļ�����ʼλ��
 *
 * Parameter:
 *      fd:�ļ�������
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_frewind(int fd);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_readddir ͨ���ļ���������ȡ�ļ���С������
 *
 * Parameter:
 *      fd:�ļ�������
 *      fileinfo_ptr:ָ��洢�ļ�״̬���ݽṹ��ָ��
 *		                
 * Return:
 *      ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int	ql_yaffs_readddir(int fd, NandFs_info *fileinfo_ptr);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffs_lstat ͨ���ļ�·����ȡ�ļ���С������
 *
 * Parameter:
 *      path:�ļ�·��
 *      fileinfo_ptr:ָ��洢�ļ�״̬���ݽṹ��ָ��
 *
 * Return:
 *     ���ظ���:��ʾ����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffs_lstat(char *path, NandFs_info *fileinfo_ptr);
/*-----------------------------------------------------------------------------------------
 * Function: ql_yaffsfs_getlasterror ͨ��yaffs�Ĵ�����
 *
 * Parameter:
 *      NULL
 *
 * Return:
 *     ���ظ���:yaffs�Ĵ�����
 *
-----------------------------------------------------------------------------------------*/
int ql_yaffsfs_getlasterror(void);


/****************************************yaffsԭ���ӿ�,֧�ַ���************************************************/
#endif


